#!/bin/bash

CONF_FILE="./observer.conf"
LOG_FILE="./observer.log"

if [ ! -f "$CONF_FILE" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') Ошибка: $CONF_FILE не найден" >> "$LOG_FILE"
    exit 1
fi
#проверяем конфиг

while IFS= read -r SCRIPT_PATH || [ -n "$SCRIPT_PATH" ]; do
#читаем конфиг
    [[ -z "$SCRIPT_PATH" || "$SCRIPT_PATH" =~ ^#.* ]] && continue
#для игнорирования комментариев и пустых строчек
    SCRIPT_NAME=$(basename "$SCRIPT_PATH")
#получаем имя скрипта
    FOUND=0
    for pid_dir in /proc/[0-9]*; do
        pid=$(basename "$pid_dir")
        if [ -f "/proc/$pid/cmdline" ]; then
            CMDLINE=$(cat /proc/$pid/cmdline 2>/dev/null | tr '\0' ' ')
            if [[ "$CMDLINE" == *"$SCRIPT_NAME"* ]]; then
                FOUND=1
                break
            fi
        fi
    done
#проверяем наличие процесса

#если процесс был найден- запускаем
    if [ $FOUND -eq 0 ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') Перезапуск $SCRIPT_NAME" >> "$LOG_FILE"

        if [ -x "$SCRIPT_PATH" ]; then
            nohup "$SCRIPT_PATH" &>/dev/null &
            echo "$(date '+%Y-%m-%d %H:%M:%S') Запущен $SCRIPT_NAME с PID $!" >> "$LOG_FILE"
        else
            echo "$(date '+%Y-%m-%d %H:%M:%S') Ошибка: $SCRIPT_PATH не исполняемый" >> "$LOG_FILE"
        fi
    fi
done < "$CONF_FILE"


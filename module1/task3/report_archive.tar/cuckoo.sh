#!/bin/bash
mkdir -p /tmp/run/
#Создаем сначала папку

rm -f /tmp/run/cuckoo.pid
mkfifo /tmp/run/cuckoo.pid
#Создаем канал, перед этим удалим старый, если есть

echo "$(date '+%d+%m+%Y %H:%M:%S') Startup!" >> cuckoo.log
#выводим сообщениe Startup! в лог

trap 'echo "$(date "+%d+%m+%Y %H:%M:%S") Shutdown!" >> cuckoo.log; exit 0' TERM
#перехватываем сигнал SIGTERM

while true; do
#непрерывно читаем из канала
	if read message < /tmp/run/cuckoo.pid; then
		if [[ $message == *"how much time do I have?"* ]]; then
			N=$((RANDOM % 9 + 2))
			Name_PID=$(echo "$message" | cut -d':' -f1 | tr -d ' ')

#Извлечение NAME_PID
echo "$(date '+%d+%m+%Y %H:%M:%S') $Name_PID $N" >> cuckoo.log
fi
fi
done
